package id.zentra.minigames;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import net.kyori.adventure.text.Component;

import java.util.*;

public final class GameManager {
    public static final List<String> KEYS = List.of("sumo", "tnttag", "crumble", "colorrush", "pillars", "tinyhunt", "duel");

    public static final class MenuHolder implements InventoryHolder {
        public Inventory inv;
        public final Map<Integer, String> keys = new HashMap<>();
        @Override public Inventory getInventory() { return inv; }
    }

    private final ZentraMinigames plugin;
    private final Map<String, List<Game>> games = new LinkedHashMap<>();
    private final Map<UUID, Game> inGame = new HashMap<>();
    private final Deque<Game> buildQueue = new ArrayDeque<>();
    private final Set<String> queued = new HashSet<>();
    private boolean building;
    private World world;

    public GameManager(ZentraMinigames plugin) { this.plugin = plugin; }

    public World world() { return world; }

    public void init(World w) {
        world = w;
        FileConfiguration c = plugin.getConfig();
        int baseX = c.getInt("arena.x", 30000), baseZ = c.getInt("arena.z", 30000), baseY = c.getInt("arena.y", 150);
        int ver = c.getInt("build-version", 1);
        if (plugin.data().getInt("build-version", 0) != ver) {
            plugin.data().set("built", null);
            plugin.data().set("build-version", ver);
            plugin.saveData();
        }
        int i = 0;
        for (String key : KEYS) {
            if (!c.getBoolean("games." + key + ".enabled", true)) continue;
            int n = Math.max(1, c.getInt("games." + key + ".instances", 2));
            List<Game> list = new ArrayList<>();
            for (int j = 0; j < n; j++) {
                Game g = create(key, j, baseX + i * 400, baseY, baseZ + j * 400);
                list.add(g);
                g.activate();
                if (plugin.isBuilt(g.id())) g.state = Game.State.WAITING;
                else queueBuild(g);
            }
            games.put(key, list);
            i++;
        }
        plugin.getLogger().info("Zentra Minigames siap di world '" + w.getName() + "'. Arena yang belum ada akan dibangun otomatis.");
        pump();
    }

    private Game create(String key, int j, int cx, int by, int cz) {
        return switch (key) {
            case "sumo" -> new SumoGame(plugin, j, cx, by, cz);
            case "tnttag" -> new TntTagGame(plugin, j, cx, by, cz);
            case "crumble" -> new CrumbleRunGame(plugin, j, cx, by, cz);
            case "colorrush" -> new ColorRushGame(plugin, j, cx, by, cz);
            case "pillars" -> new PillarsGame(plugin, j, cx, by, cz);
            case "tinyhunt" -> new TinyHuntGame(plugin, j, cx, by, cz);
            case "duel" -> new DuelGame(plugin, j, cx, by, cz);
            default -> throw new IllegalArgumentException(key);
        };
    }

    private void queueBuild(Game g) {
        if (!queued.add(g.id())) return;
        g.state = Game.State.RESETTING;
        buildQueue.add(g);
    }

    private void pump() {
        if (building) return;
        Game g = buildQueue.poll();
        if (g == null) return;
        building = true;
        plugin.getLogger().info("Membangun arena " + g.id() + " ...");
        g.build(() -> {
            plugin.markBuilt(g.id(), true);
            queued.remove(g.id());
            g.state = Game.State.WAITING;
            building = false;
            plugin.getLogger().info("Arena " + g.id() + " selesai.");
            pump();
        });
    }

    public void rebuild(String key) {
        for (Map.Entry<String, List<Game>> en : games.entrySet()) {
            if (!key.equals("all") && !en.getKey().equals(key)) continue;
            for (Game g : en.getValue()) {
                if (!g.players.isEmpty()) continue;
                plugin.markBuilt(g.id(), false);
                queueBuild(g);
            }
        }
        pump();
    }

    public void shutdown() {
        for (List<Game> l : games.values()) for (Game g : l) g.shutdown();
        inGame.clear();
    }

    // ---------- pemain ----------
    public Game of(Player p) { return inGame.get(p.getUniqueId()); }
    public void forget(UUID u) { inGame.remove(u); }
    public List<Game> list(String key) { return games.get(key); }
    public Set<String> keys() { return games.keySet(); }

    public Game gameAt(Location loc) {
        if (world == null || loc.getWorld() != world) return null;
        for (List<Game> l : games.values())
            for (Game g : l)
                if (Math.abs(loc.getX() - g.cx) < 140 && Math.abs(loc.getZ() - g.cz) < 140) return g;
        return null;
    }

    public void join(Player p, String key) {
        if (world == null) { Msg.send(p, "&cPlugin masih memuat world, coba beberapa detik lagi."); return; }
        if (inGame.containsKey(p.getUniqueId())) { Msg.send(p, "&cKamu sudah ada di dalam game. Pakai &e/zm leave&c."); return; }
        List<Game> l = games.get(key);
        if (l == null) { Msg.send(p, "&cGame tidak ditemukan atau dimatikan."); return; }
        Game best = null;
        for (Game g : l) {
            if (!g.joinable()) continue;
            if (best == null || g.players.size() > best.players.size()) best = g;
        }
        if (best == null) {
            boolean preparing = false;
            for (Game g : l) if (g.state == Game.State.RESETTING) preparing = true;
            Msg.send(p, preparing ? "&eArena &f" + l.get(0).name + " &esedang disiapkan, tunggu sebentar."
                    : "&cSemua arena &f" + l.get(0).name + " &csedang berjalan atau penuh.");
            return;
        }
        if (best.join(p)) inGame.put(p.getUniqueId(), best);
    }

    public boolean leave(Player p) {
        Game g = inGame.remove(p.getUniqueId());
        if (g == null) return false;
        g.leave(p);
        return true;
    }

    public void setOpen(String key, boolean open) {
        List<Game> l = games.get(key);
        if (l != null) for (Game g : l) g.open = open;
    }

    // ---------- menu ----------
    public void openMenu(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = Bukkit.createInventory(h, 27, Msg.c("&b&lZentra &3&lMinigames"));
        h.inv = inv;
        ItemStack pane = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta pm = pane.getItemMeta();
        pm.displayName(Msg.c(" "));
        pane.setItemMeta(pm);
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        int idx = 0;
        for (Map.Entry<String, List<Game>> en : games.entrySet()) {
            if (idx >= slots.length) break;
            Game f = en.getValue().get(0);
            int total = 0;
            boolean openAny = false;
            for (Game g : en.getValue()) { total += g.players.size(); if (g.joinable()) openAny = true; }
            ItemStack it = new ItemStack(f.icon);
            ItemMeta m = it.getItemMeta();
            m.displayName(Msg.c("&b&l" + f.name));
            List<Component> lore = new ArrayList<>();
            for (String r : f.rules) lore.add(Msg.c("&7" + r));
            lore.add(Msg.c(" "));
            lore.add(Msg.c("&fPemain: &a" + total + " &8| &fMinimal: &e" + f.min));
            lore.add(Msg.c(openAny ? "&aKlik untuk bergabung" : "&cSedang berjalan / penuh"));
            m.lore(lore);
            it.setItemMeta(m);
            inv.setItem(slots[idx], it);
            h.keys.put(slots[idx], en.getKey());
            idx++;
        }
        if (inGame.containsKey(p.getUniqueId())) {
            ItemStack b = new ItemStack(Material.BARRIER);
            ItemMeta bm = b.getItemMeta();
            bm.displayName(Msg.c("&c&lKeluar dari game"));
            b.setItemMeta(bm);
            inv.setItem(22, b);
            h.keys.put(22, "_leave");
        }
        p.openInventory(inv);
    }
}
