# Zentra Minigames

Plugin minigame untuk Purpur/Paper 1.21+ (api-version 1.21, dicompile terhadap paper-api 1.21.4).
Semua arena dibangun otomatis, melayang, di world `pvp` pada koordinat jauh (default X/Z 30000, Y 150).

## Build
1. Install JDK 21 dan Maven.
2. Di folder ini jalankan: `mvn clean package`
3. Ambil `target/ZentraMinigames.jar`, taruh di `plugins/`, restart server.

## Pertama kali jalan
- Pastikan world `pvp` sudah ada di Multiverse. Ganti nama world di `config.yml` kalau beda.
- Arena dibangun bertahap otomatis (ada log "Membangun arena ..."). Tunggu sampai semua selesai.
- Arena yang sudah jadi tidak dibangun ulang. Untuk memaksa: `/zm build <game|all>` atau naikkan `build-version` di config.

## Command
- `/zm` menu, `/zm join <game>`, `/zm leave`, `/zm list`, `/zm rules <game>`
- Admin (`zentra.minigames.admin`): `/zm build <game|all>`, `/zm forcestart`, `/zm open|close <game>`, `/zm reload`

## Game (kode)
sumo, tnttag, crumble, colorrush, pillars, tinyhunt, duel
